﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APISAPIENCIA.Models;
using Microsoft.AspNetCore.Mvc;
using APISAPIENCIA.Data;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;



namespace APISAPIENCIA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
   
    public class ValuesController : ControllerBase
    {
        private readonly ValuesRepository _repository;
       
        public ValuesController(MatriculasRepository repository)
        {
            this._repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        /// <summary>
        ///  
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [EnableCors("PermitirApiRequest")]
        public async Task<ActionResult<IEnumerable<Matriculados>>> Get()
        {
            return await _repository.GetAll();
        }

       
    }
}
