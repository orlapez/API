﻿using API.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;


namespace API.Data
{
    public class MatriculasRepository
    {
        private readonly string _connectionString;

        public MatriculasRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("defaultConnection");
        }

        public async Task<List<api>> GetAll()
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP", sql))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    var response = new List<api>();
                    await sql.OpenAsync();

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response.Add(MapToValue(reader));
                        }
                    }

                    return response;
                }
            }
        }

        private api MapToValue(SqlDataReader reader)
        {
            return new api()
            {




variable = Convert.ToInt32(reader["ID"]),
Codigo = reader["Código"].ToString(),



            };
        }


    }
}
