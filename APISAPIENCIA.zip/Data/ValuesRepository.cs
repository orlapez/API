﻿using APISAPIENCIA.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;


namespace APISAPIENCIA.Data
{
    public class ValuesRepository
    {
        private readonly string _connectionString;

        public ValuesRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("apiConnection");
        }

        public async Task<List<Values>> GetAll()
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP", sql))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    var response = new List<Values>();
                    await sql.OpenAsync();

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response.Add(MapToValue(reader));
                        }
                    }

                    return response;
                }
            }
        }

        private Values MapToValue(SqlDataReader reader)
        {
            return new Values()
            {




ID = Convert.ToInt32(reader["ID"]),
Codigo = reader["Código"].ToString(),



            };
        }


    }
}
