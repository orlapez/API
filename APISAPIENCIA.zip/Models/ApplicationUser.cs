﻿using Microsoft.AspNetCore.Identity;

namespace APISAPIENCIA.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
