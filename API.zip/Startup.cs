using API.Contexts;
using API.Data;
using System;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Reflection;
using System.IO;
using Swashbuckle.AspNetCore.Annotations;


namespace API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {


            services.AddCors(options =>
               {
                   options.AddPolicy("PermitirApiRequest",
                       builder => builder.WithOrigins("https://apirequest.io").WithMethods("GET").AllowAnyHeader());
               });

            services.AddDbContext<ApplicationDbContext>(options =>

               
            options.UseSqlServer(Configuration.GetConnectionString("UsersConnection")));

            services.AddControllers();


            services.AddIdentity<API.Models.ApplicationUser, IdentityRole>()
           .AddEntityFrameworkStores<ApplicationDbContext>()
           .AddDefaultTokenProviders();

            services.AddScoped<APIRepository>();

            services.AddSwaggerGen(config =>
            {
                config.SwaggerDoc("v1", new OpenApiInfo
                {

                    Version = "V1",
                    Title = " API",
                    Description = "",
                    TermsOfService = new Uri("https://WWW/terminos"),
                    License = new OpenApiLicense()
                    {
                        Name = "API",
                        Url = new Uri("https://WWWterminos")
                    },
                    Contact = new OpenApiContact()
                    {
                        Name = "oa",
                        Email = "oa@",
                        Url = new Uri("https://www")
                    }
                });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                config.IncludeXmlComments(xmlPath);
            });

              

         


            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                             .AddJwtBearer(options =>
                 options.TokenValidationParameters = new TokenValidationParameters
                 {
                     ValidateIssuer = false,
                     ValidateAudience = false,
                     ValidateLifetime = true,
                     ValidateIssuerSigningKey = true,
                     IssuerSigningKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(Configuration["jwt:key"])),
                     ClockSkew = TimeSpan.Zero
                 });
           

        }




     // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
            public void Configure(IApplicationBuilder app, IWebHostEnvironment env)


{

            app.UseSwagger();

            app.UseSwaggerUI(config =>
              {
                  config.SwaggerEndpoint("./swagger.json", "API v1");


              });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }





            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseCors();
            
            
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });


        }

        }

    }

